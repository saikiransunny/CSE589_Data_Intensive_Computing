Submitted done by:
Sai Kiran Putta
Hari Krishna Rangineeni

Project Done in : Pyspark using Virtual Machine

Running the code : spark-submit nytimes_spark.py

Output : The output explains the accuracy of trainingset, testset and the unseen-finaldata


